// You can require() this file in a CommonJS environment.
require('./dist/js/flat-ui.js');
